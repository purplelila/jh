package com.example.cafeInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
