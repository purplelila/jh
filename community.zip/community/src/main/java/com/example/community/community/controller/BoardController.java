package com.example.community.controller;

import com.example.community.service.BoardService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@RestController
@RequestMapping("/api/board")
public class BoardController {

    private final BoardService boardService;

    @Value("${file.upload.dir}")
    private String uploadDir;

    public BoardController(BoardService boardService) {
        this.boardService = boardService;
    }

    // 게시글 등록
    @PostMapping("/{category}")
    public ResponseEntity<?> createPost(
            @PathVariable String category,
            @RequestParam("title") String title,
            @RequestParam("content") String content,
            @RequestParam(value = "files", required = false) List<MultipartFile> files
    ) {
        try {
            boardService.savePost(title, content, category, files);
            return ResponseEntity.ok("게시글이 성공적으로 저장되었습니다.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("게시글 저장 실패: " + e.getMessage());
        }
    }

    // 이미지 업로드 (CKEditor에서 사용)
    @PostMapping("/image-upload")
    public ResponseEntity<?> uploadImage(@RequestParam("upload") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("uploaded", false, "error", Map.of("message", "빈 파일입니다.")));
            }

            String originalFilename = file.getOriginalFilename();
            String savedFilename = UUID.randomUUID() + "_" + originalFilename;
            Path savePath = Paths.get(uploadDir, savedFilename);
            Files.createDirectories(savePath.getParent());
            Files.copy(file.getInputStream(), savePath);

            String imageUrl = "/uploads/" + savedFilename;

            // ✅ CKEditor에서 인식 가능한 정식 JSON 구조로 반환
            Map<String, Object> response = new HashMap<>();
            response.put("uploaded", true);
            response.put("url", imageUrl);
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("uploaded", false, "error", Map.of("message", "업로드 실패: " + e.getMessage())));
        }
    }
    // 게시글 전체 목록 조회
    @GetMapping
    public ResponseEntity<?> getAllPosts() {
        try {
            return ResponseEntity.ok(boardService.getAllPosts());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("게시글 목록 조회 실패: " + e.getMessage());
        }
    }


}
