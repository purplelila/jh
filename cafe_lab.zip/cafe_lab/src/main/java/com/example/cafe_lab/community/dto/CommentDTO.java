package com.example.cafe_lab.community.dto;

import com.example.cafe_lab.community.entity.CommentEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class CommentDTO {
    private Long id;
    private Long boardId;
    private String author;
    private String comment;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public CommentDTO(CommentEntity entity) {
        this.id = entity.getId();
        this.boardId = entity.getBoard().getId();
        this.author = entity.getAuthor();
        this.comment = entity.getComment();
        this.createdAt = entity.getCreatedAt();
    }

    public CommentDTO(Long id, String author, String comment, LocalDateTime createdAt) {
        this.id = id;
        this.author = author;
        this.comment = comment;
        this.createdAt = createdAt;
    }
}
