package com.example.cafe_lab.community.controller;

import com.example.cafe_lab.admin.Users;
import com.example.cafe_lab.admin.lognin.LoginRepository;
import com.example.cafe_lab.community.dto.BoardDTO;
import com.example.cafe_lab.community.dto.BoardDetailDTO;
import com.example.cafe_lab.community.service.BoardService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@RestController
@RequestMapping("/api/board")
public class BoardController {

    private final BoardService boardService;
    private final LoginRepository loginRepository;

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Autowired
    public BoardController(BoardService boardService, LoginRepository loginRepository) {
        this.boardService = boardService;
        this.loginRepository = loginRepository;
    }

    // 게시글 등록
    @PostMapping("/{category}")
    public ResponseEntity<?> saveBoard(
            @PathVariable("category") String category,
            @RequestParam("title") String title,
            @RequestParam("textContent") String textContent,
            @RequestParam(value = "imageUrls", required = false) String imageUrlsJson,
            @RequestPart(value = "imageFiles", required = false) List<MultipartFile> imageFiles,
            @RequestPart(value = "files", required = false) List<MultipartFile> files
    ) {
        try {
            // 인증된 사용자 정보 가져오기
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Object principal = authentication.getPrincipal();

            String userIdStr = null;
            if (principal instanceof String) {
                userIdStr = (String) principal; // principal이 String일 경우
            } else if (principal instanceof UserDetails) {
                userIdStr = ((UserDetails) principal).getUsername(); // principal이 UserDetails일 경우
            }

            if (userIdStr == null) {
                throw new RuntimeException("사용자 정보를 찾을 수 없습니다.");
            }

            // User ID로 Users 객체 조회
            Users user = loginRepository.findByUserid(userIdStr)
                    .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));

            // 로그인한 사용자의 닉네임 가져오기
            String nickname = user.getNickname(); // Users 객체에서 닉네임 가져오기

            // imageUrls 처리
            List<String> imageUrls = new ArrayList<>();
            if (imageUrlsJson != null && !imageUrlsJson.isEmpty()) {
                imageUrls = new ObjectMapper().readValue(imageUrlsJson, new TypeReference<List<String>>() {});
            }

            // 게시글을 저장하며, 로그인한 사용자의 닉네임을 사용
            boardService.savePost(user, category, title, textContent, nickname, imageUrls, files, imageFiles);

            return ResponseEntity.ok("게시글 등록 완료!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("게시글 등록 실패: " + e.getMessage());
        }
    }

    // 이미지 업로드 (CKEditor에서 사용)
    @PostMapping(value = "/image-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadImage(@RequestParam("upload") MultipartFile file, HttpServletRequest request) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("uploaded", false, "error", Map.of("message", "빈 파일입니다.")));
            }

            String originalFilename = file.getOriginalFilename();
            String savedFilename = UUID.randomUUID() + "_" + originalFilename;
            Path savePath = Paths.get(uploadDir, savedFilename);
            Files.createDirectories(savePath.getParent());
            Files.copy(file.getInputStream(), savePath);

            String imageUrl = "/uploads/" + savedFilename;

            // 현재 요청을 기준으로 "http://localhost:8080" 부분을 가져와 준다
            String baseUrl = ServletUriComponentsBuilder.fromRequestUri(request)
                    .replacePath(null)     // path 제거 -> http://localhost:8080
                    .build()
                    .toUriString();

            String fullUrl = baseUrl + imageUrl;

            // ✅ CKEditor에서 인식 가능한 정식 JSON 구조로 반환
            Map<String, Object> response = new HashMap<>();
            response.put("uploaded", true);
            response.put("url", imageUrl);
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("uploaded", false, "error", Map.of("message", "업로드 실패: " + e.getMessage())));
        }
    }

    // 게시글 전체 목록
    @GetMapping
    public ResponseEntity<?> getAllPosts() {
        try {
            List<BoardDTO> posts = boardService.getAllPosts();

            // 게시글 목록에 작성자 닉네임 포함
            for (BoardDTO post : posts) {
                // 이미 DTO에 nickname이 들어 있다면 이 줄은 불필요함
                // 필요하다면 아래처럼 사용
                String nickname = post.getNickname();
                post.setNickname(nickname);
            }
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("게시글 목록 조회 실패: " + e.getMessage());
        }
    }

    // 게시글 상세 조회 (본문 + 댓글 포함)
    @GetMapping("/{category}/{postId}")
    public ResponseEntity<?> getPostDetailWithComments(@PathVariable("category") String category, @PathVariable("postId") Long postId) {
        try {
            BoardDetailDTO detail = boardService.getPostDetail(postId);
            return ResponseEntity.ok(detail);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("게시글을 찾을 수 없습니다.");
        }
    }

    // 파일 다운로드 (원본 파일명 유지)
    @GetMapping("/download/{filename:.+}")
    public ResponseEntity<FileSystemResource> downloadFile(@PathVariable("filename") String filename) throws IOException {
        File file = new File(uploadDir + "/" + filename);

        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }

        // 원본 파일 이름을 그대로 사용
        String originalFilename = filename;

        // 파일 이름을 URL 인코딩
        String encodedFilename = URLEncoder.encode(originalFilename, StandardCharsets.UTF_8).replaceAll("\\+", "%20");

        String contentType = Files.probeContentType(file.toPath());
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        FileSystemResource resource = new FileSystemResource(file);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename*=UTF-8''" + encodedFilename)
                .header("Content-Type", contentType)
                .body(resource);
    }
}
