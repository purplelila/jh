package com.example.cafe_lab.community.service;

import com.example.cafe_lab.admin.Users;
import com.example.cafe_lab.admin.lognin.LoginRepository;
import com.example.cafe_lab.community.dto.BoardDetailDTO;
import com.example.cafe_lab.community.dto.CommentDTO;
import com.example.cafe_lab.community.entity.BoardEntity;
import com.example.cafe_lab.community.entity.BoardFileEntity;
import com.example.cafe_lab.community.entity.ComImgEntity;
import com.example.cafe_lab.community.repository.BoardFileRepository;
import com.example.cafe_lab.community.repository.BoardImageRepository;
import com.example.cafe_lab.community.repository.BoardRepository;
import com.example.cafe_lab.community.dto.BoardDTO;
import com.example.cafe_lab.community.dto.BoardFileDTO;
import com.example.cafe_lab.community.repository.CommentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class BoardService {

    private final BoardRepository boardRepository;
    private final BoardFileRepository boardFileRepository;
    private final CommentService commentService;
    private final LoginRepository loginRepository;
    private final CommentRepository commentRepository;
    private final BoardImageRepository boardImageRepository;

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Autowired
    public BoardService(BoardRepository boardRepository, BoardFileRepository boardFileRepository,
                        CommentService commentService, LoginRepository loginRepository,
                        CommentRepository commentRepository, BoardImageRepository boardImageRepository) {
        this.boardRepository = boardRepository;
        this.boardFileRepository = boardFileRepository;
        this.commentService = commentService;
        this.loginRepository = loginRepository;
        this.commentRepository = commentRepository;
        this.boardImageRepository= boardImageRepository;
    }

    // 게시글 목록 조회
    public List<BoardDTO> getAllPosts() {
        return boardRepository.findAllWithUser().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // 엔티티를 DTO로 변환하면서 닉네임 포함
    public BoardDTO convertToDTO(BoardEntity boardEntity) {
        List<BoardFileDTO> fileDTOs = boardEntity.getFiles().stream()
                .map(file -> new BoardFileDTO(
                        file.getOriginalName(),
                        file.getSavedName(),
                        "/api/board/download/" + file.getSavedName(),
                        file.getSize(),
                        file.getPath(),
                        file.getFileType(),
                        file.getBoard().getId()
                ))
                .collect(Collectors.toList());

        BoardDTO dto = new BoardDTO();
        dto.setId(boardEntity.getId());
        dto.setTitle(boardEntity.getTitle());
        dto.setTextContent(boardEntity.getTextContent());
        dto.setCategory(boardEntity.getCategory());
        dto.setCreateDate(boardEntity.getCreatedAt());
        dto.setFiles(fileDTOs);
        dto.setNickname(boardEntity.getUser().getNickname()); // ✅ 닉네임 포함

        return dto;
    }

    // 게시글 저장
    public void savePost(Users user, String category, String title, String textContent, String nickname, List<String> imageUrls, List<MultipartFile> files, List<MultipartFile> imageFiles) {
        BoardEntity board = new BoardEntity();
        board.setCategory(category);
        board.setTitle(title);
        board.setTextContent(textContent);
        board.setUser(user);

        String baseUrl = ServletUriComponentsBuilder.fromCurrentContextPath().build().toUriString();

        List<ComImgEntity> imageEntities = new ArrayList<>();
        if (imageFiles != null && !imageFiles.isEmpty()) {
            for (MultipartFile imageFile : imageFiles) {
                String originalFilename = imageFile.getOriginalFilename();
                String fileExtension = originalFilename != null ? originalFilename.substring(originalFilename.lastIndexOf(".")) : ".jpg";
                String savedFilename = UUID.randomUUID().toString() + fileExtension;
                Path path = Paths.get(uploadDir + "/" + savedFilename);

                try {
                    Files.copy(imageFile.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

                    ComImgEntity imageEntity = new ComImgEntity();
                    imageEntity.setImgName(originalFilename);
                    imageEntity.setImgSize(imageFile.getSize());
                    imageEntity.setImgType(imageFile.getContentType());
                    imageEntity.setImgUrl(baseUrl + "/uploads/" + savedFilename);
                    imageEntity.setBoard(board);

                    imageEntities.add(imageEntity);
                } catch (IOException e) {
                    throw new RuntimeException("이미지 업로드 중 오류 발생", e);
                }
            }
        }
        board.setImages(imageEntities);

        List<BoardFileEntity> fileEntities = new ArrayList<>();
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                String originalFilename = file.getOriginalFilename();
                String fileExtension = originalFilename != null ? originalFilename.substring(originalFilename.lastIndexOf(".")) : ".tmp";
                String savedFilename = UUID.randomUUID().toString() + fileExtension;
                Path path = Paths.get(uploadDir + "/" + savedFilename);

                try {
                    Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

                    BoardFileEntity fileEntity = new BoardFileEntity();
                    fileEntity.setOriginalName(originalFilename);
                    fileEntity.setSavedName(savedFilename);
                    fileEntity.setSize(file.getSize());
                    fileEntity.setPath(path.toString());
                    fileEntity.setFileType(file.getContentType());
                    fileEntity.setBoard(board);

                    fileEntities.add(fileEntity);
                } catch (IOException e) {
                    throw new RuntimeException("파일 업로드 중 오류 발생", e);
                }
            }
        }
        board.setFiles(fileEntities);

        boardRepository.save(board);
    }

    // 게시글 ID로 조회 (카테고리 포함)
    public BoardDTO getPostById(String category, Long id) {
        BoardEntity post = boardRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("게시글이 존재하지 않습니다."));

        return convertToDTO(post); // ✅ 닉네임 포함된 DTO 사용
    }

    // 상세보기 DTO 반환
    public BoardDetailDTO getPostDetail(Long postId) {
        BoardEntity board = boardRepository.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("게시글이 없습니다."));

        List<CommentDTO> commentDTOs = commentService.getCommentsByBoardId(postId);

        List<BoardFileDTO> fileDTOs = board.getFiles().stream()
                .map(BoardFileDTO::new)
                .collect(Collectors.toList());

        return new BoardDetailDTO(board, commentDTOs, fileDTOs);
    }

    @Transactional
    public void deletePost(Long postId) {
        // 1. 게시글 조회
        BoardEntity post = boardRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("게시물이 존재하지 않습니다."));

        // 2. 댓글 삭제
        commentRepository.deleteByBoard_Id(postId);

        // 3. 이미지 삭제
        List<ComImgEntity> images = boardImageRepository.findByBoardId(postId);
        for (ComImgEntity image : images) {
            File imgFile = new File(uploadDir + "/" + image.getImgName());
            if (imgFile.exists()) {
                imgFile.delete();
            }
            boardImageRepository.delete(image);
        }

        // 4. 파일 삭제
        List<BoardFileEntity> files = boardFileRepository.findByBoard_Id(postId);
        for (BoardFileEntity file : files) {
            File storedFile = new File(uploadDir + "/" + file.getSavedName());
            if (storedFile.exists()) {
                storedFile.delete();
            }
            boardFileRepository.delete(file);
        }

        // 5. 게시글 삭제
        boardRepository.delete(post);
    }

    public BoardEntity getPostEntityById(String category, Long postId) {
        return boardRepository.findByCategoryAndId(category, postId).orElse(null);
    }
}
