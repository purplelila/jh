package com.example.cafe_lab.community.service;

import com.example.cafe_lab.community.dto.CommentDTO;
import com.example.cafe_lab.community.entity.BoardEntity;
import com.example.cafe_lab.community.entity.CommentEntity;
import com.example.cafe_lab.community.repository.BoardRepository;
import com.example.cafe_lab.community.repository.CommentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CommentService {

    private final CommentRepository commentRepository;
    private final BoardRepository boardRepository;

    // 댓글 목록 조회
    public List<CommentDTO> getCommentsByBoardId(Long postId) {
        List<CommentEntity> comments = commentRepository.findByBoardId(postId);
        return comments.stream()
                .map(CommentDTO::new)
                .collect(Collectors.toList());
    }

    public CommentDTO addComment(Long boardId, CommentDTO dto) {
        BoardEntity board = boardRepository.findById(boardId)
                .orElseThrow(() -> new IllegalArgumentException("해당 게시물이 존재하지 않습니다."));
        CommentEntity comment = new CommentEntity();
        comment.setBoard(board);
        comment.setAuthor(dto.getAuthor());
        comment.setComment(dto.getComment());
        comment.setCreatedAt(LocalDateTime.now());
        comment.setUpdatedAt(LocalDateTime.now());
        CommentEntity saved = commentRepository.save(comment);
        return toDTO(saved);
    }

    public void deleteComment(Long commentId) {
        commentRepository.deleteById(commentId);
    }

    private CommentDTO toDTO(CommentEntity entity) {
        CommentDTO dto = new CommentDTO();
        dto.setId(entity.getId());
        dto.setBoardId(entity.getBoard().getId());
        dto.setAuthor(entity.getAuthor());
        dto.setComment(entity.getComment());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        return dto;
    }
}