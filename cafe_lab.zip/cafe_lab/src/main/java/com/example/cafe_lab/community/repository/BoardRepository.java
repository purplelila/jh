package com.example.cafe_lab.community.repository;

import com.example.cafe_lab.community.entity.BoardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoardRepository extends JpaRepository<BoardEntity, Long> {
    @Query("SELECT b FROM BoardEntity b JOIN FETCH b.user")
    List<BoardEntity> findAllWithUser();

}
